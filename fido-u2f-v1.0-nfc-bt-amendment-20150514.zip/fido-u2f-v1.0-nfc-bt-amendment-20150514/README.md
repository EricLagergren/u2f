U2F specifications

This is the set of specifications to read in preparation for the Review Draft vote. Please fido-u2f-GUIDE-TO-DOCS.txt in the directory first.

Sam Srinivas
samsrinivas@google.com
U2F Workgroup Chair
