resources
=========

Resources shared by spec repositories, e.g. respec build, css files, etc.
